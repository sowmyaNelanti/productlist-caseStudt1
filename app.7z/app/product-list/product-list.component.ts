import { Component, OnInit } from '@angular/core';
import {ProductListService} from '../product-list.service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

noOfButtons;
noOfButtonsArray=[];
p:number=1;

productList=[]
  constructor(private productListService:ProductListService) { }

getProductlist():void{
  this.productListService.getProductlist().subscribe((product:any[])=>this.productList=product);
}

  ngOnInit() {
    this.getProductlist();
    //this.createDynamicButtons();
  }
// createDynamicButtons(){
//   this.noOfButtons=Math.ceil(this.productList.length/5)
  
//   for(var i=0;i<this.noOfButtons;i++){
//     var button={
//       "id":"button"+i,
//       "index":i
//     }
//     console.log(button);
//     this.noOfButtonsArray.push(i+1);
//   }
 
}



  
  
 

}
